puts "What is your mood today?"
mood = gets.chomp
puts mood.length
puts "meow #{mood}"
