puts "Time for Mad Libs"
puts "Provide a word for each type requested"
puts "Adjective"
word1 = gets.chomp
puts "Adjective"
word2 = gets.chomp
puts "Noun"
word3 = gets.chomp
puts "Noun"
word4 = gets.chomp
puts "Plural noun"
word5 = gets.chomp
puts "Game"
word6 = gets.chomp
puts "Plural noun"
word7 = gets.chomp
puts "Verb ending in 'ing'"
word8 = gets.chomp
puts "Verb ending in 'ing'"
word9 = gets.chomp
puts "Plural noun"
word10 = gets.chomp
puts "Verb ending in 'ing'"
word11 = gets.chomp
puts "Noun"
word12 = gets.chomp
puts "Plant"
word13 = gets.chomp
puts "Part of the body"
word14 = gets.chomp
puts "A place"
word15 = gets.chomp
puts "Verb ending in 'ing'"
word16 = gets.chomp
puts "Adjective"
word17 = gets.chomp
puts "Number"
word18 = gets.chomp
puts "Plural noun"
word19 = gets.chomp
puts  "A vacation is when you take a trip to some #{word1} place with your #{word2} family. Usually you go to some place that is near a/an #{word3} or up on a/an #{word4}. A good vacation place is one where you can ride #{word5} or play #{word6} or go hunting for #{word7}. I like to spend my time #{word8} or #{word9}. When parents go on a vaction, they spend their time eating three #{word10} a day, and fathers play golf, and mothers sit around #{word11}. Last summer, my little brother fell in a/an #{word12} and got poison #{word13} all over his #{word14}. My family is going to go to (the) #{word15}, and I will practice #{word16}. Parents need vacations more than kids because parents are always very #{word17} and because they have to work #{word18} hours every day all year making enough #{word19} to pay for the vacation."
