puts "Enter the cost of your meal, please."
dinner = gets.chomp.to_f
tip = dinner * 0.18
puts "18% tip is #{tip.round(2)}"
