puts "Enter two numbers, please."
num1 = gets.chomp.to_f
num2 = gets.chomp.to_f
sum = num1 + num2
diff = num1 - num2
prod = num1 * num2
quo = num1 / num2
puts "The sum of #{num1} and #{num2} is #{sum}"
puts "The difference between #{num1} and #{num2} is #{diff}"
puts "The product of #{num1} and #{num2} is #{prod}"
puts "The quotient of #{num1} and #{num2} is #{quo}"
