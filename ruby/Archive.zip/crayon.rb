puts "What is your favorite color of Crayola Crayon?"
crayon = gets.chomp
puts crayon.upcase.reverse
